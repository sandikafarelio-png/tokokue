<?php 
include '../koneksi.php';
session_start();

// 1. Pastikan parameter ada agar tidak muncul error sekilas
if(!isset($_GET['produk']) || !isset($_GET['kd_cs'])){
    header('location:../index.php');
    exit;
}

$kode_produk = mysqli_real_escape_string($conn, $_GET['produk']);
$kode_customer = mysqli_real_escape_string($conn, $_GET['kd_cs']);

// 2. Ambil data produk
$query_p = mysqli_query($conn, "SELECT * FROM produk WHERE kode_produk = '$kode_produk'");
$p = mysqli_fetch_assoc($query_p);

// 3. VALIDASI: Jika produk tidak ditemukan, JANGAN masukkan ke keranjang
if(!$p){
    echo "<script>alert('Gagal: Kode Produk $kode_produk tidak ditemukan di database!'); window.location='../index.php';</script>";
    exit;
}

$nama_produk = $p['nama'];
$harga = $p['harga'];

// 4. Cek apakah produk sudah ada di keranjang
$cek = mysqli_query($conn, "SELECT * FROM keranjang WHERE kode_produk = '$kode_produk' AND kode_customer = '$kode_customer'");

if(mysqli_num_rows($cek) > 0){
    $row_k = mysqli_fetch_assoc($cek);
    $qty_baru = $row_k['qty'] + 1;
    mysqli_query($conn, "UPDATE keranjang SET qty = '$qty_baru' WHERE kode_produk = '$kode_produk' AND kode_customer = '$kode_customer'");
} else {
    // Masukkan data valid
    mysqli_query($conn, "INSERT INTO keranjang (kode_customer, kode_produk, nama_produk, qty, harga) 
                         VALUES ('$kode_customer', '$kode_produk', '$nama_produk', '1', '$harga')");
}

// 5. Gunakan exit setelah header agar script benar-benar berhenti
header('location:../keranjang.php');
exit;
?>