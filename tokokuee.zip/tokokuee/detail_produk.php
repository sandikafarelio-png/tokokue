<?php 
include 'header.php';

// Menangkap kode produk dari URL
$kode = $_GET['produk'];

// --- AREA EDIT MANUAL ---
// Di sini Anda tentukan isinya berdasarkan kode produk yang diklik
if ($kode == 'P0001') {
    $nama      = "Bolu Pulut Hitam Keju";
    $harga     = 85000;
    $deskripsi = "Bolu lembut dengan pulut hitam asli dan taburan keju melimpah.";
    $image     = "bolupuluthitam.jpg";
} 
elseif ($kode == 'P0002') {
    $nama      = "Bolu Jadul";
    $harga     = 70000;
    $deskripsi = "Cita rasa klasik bolu jadul yang tak terlupakan.";
    $image     = "bolu.jpg";
} 
elseif ($kode == 'P0003') {
    $nama      = "Bolu Zebra";
    $harga     = 70000;
    $deskripsi = "Bolu dengan motif zebra coklat vanilla yang cantik dan lembut.";
    $image     = "boluzebra.jpg";
}
elseif ($kode == 'P0004') {
    $nama      = "Bolu Keju";
    $harga     = 70000;
    $deskripsi = "Bolu panggang dengan rasa keju yang gurih.";
    $image     = "bolukeju.jpg";
}
elseif ($kode == 'P0005') {
    $nama      = "Bolu Pandan";
    $harga     = 70000;
    $deskripsi = "Aroma pandan asli dengan tekstur yang sangat empuk.";
    $image     = "bolupandan.jpg";
}
elseif ($kode == 'P0006') {
    $nama      = "Bolu Caramel";
    $harga     = 70000;
    $deskripsi = "Bolu sarang semut dengan rasa caramel yang legit.";
    $image     = "bolucaramel.jpg";
}
elseif ($kode == 'P0007') {
    $nama      = "Bolu Komojo";
    $harga     = 65000;
    $deskripsi = "Bolu komojo dengan motif cantik.";
    $image     = "bolukomojo.jpg";
}
elseif ($kode == 'P0008') {
    $nama      = "Cake";
    $harga     = 70000;
    $deskripsi = "bolu lembut dengan lapisan krim istimewa.";
    $image     = "cake.jpg";
}
elseif ($kode == 'P0009') {
    $nama      = "Cheese Cake";
    $harga     = 65000;
    $deskripsi = "Kue keju panggang yang lumer di mulut.";
    $image     = "cheesecake.jpg";
}
elseif ($kode == 'P0010') {
    $nama      = "Bika Ambon";
    $harga     = 65000;
    $deskripsi = "Kue tradisional bika ambon dengan tekstur berserat dan legit.";
    $image     = "bikaambon.jpg";
}
elseif ($kode == 'P0011') {
    $nama      = "Lapis Legit";
    $harga     = 65000;
    $deskripsi = "Kue lapis legit premium dengan aroma rempah yang harum.";
    $image     = "lapislegit.jpg";
}
elseif ($kode == 'P0012') {
    $nama      = "Kue Sus";
    $harga     = 65000;
    $deskripsi = "Kue sus dengan isian vla vanilla yang melimpah.";
    $image     = "kuesus.jpg";
}
elseif ($kode == 'P0013') {
    $nama      = "Croissant";
    $harga     = 40000;
    $deskripsi = "Roti prancis yang renyah di luar dan lembut di dalam.";
    $image     = "croisant.jpg";
}
elseif ($kode == 'P0014') {
    $nama      = "Pie";
    $harga     = 35000;
    $deskripsi = "Kulit pie renyah dengan topping buah-buahan segar.";
    $image     = "pie.jpg";
}
elseif ($kode == 'P0015') {
    $nama      = "Bolen";
    $harga     = 30000;
    $deskripsi = "Pisang bolu lilit dengan coklat dan keju.";
    $image     = "bolen.jpg";
}
elseif ($kode == 'P0016') {
    $nama      = "Brownies Cookies";
    $harga     = 35000;
    $deskripsi = "Perpaduan renyahnya cookies dan lembutnya brownies.";
    $image     = "BrowniesCokies.jpg";
}
elseif ($kode == 'P0017') {
    $nama      = "Chocolate Swiss Roll";
    $harga     = 60000;
    $deskripsi = "Bolu gulung coklat dengan isian krim coklat pekat.";
    $image     = "ChocolateSwissRoll.jpg";
}
elseif ($kode == 'P0018') {
    $nama      = "Donut Keju";
    $harga     = 15000;
    $deskripsi = "Donat lembut dengan taburan keju melimpah.";
    $image     = "donutkeju.jpg";
}
// Tambahkan elseif baru di sini jika ada menu baru
/*
elseif ($kode == 'KODE_BARU') {
    $nama      = "NAMA MENU";
    $harga     = 50000;
    $deskripsi = "DESKRIPSI MENU";
    $image     = "NAMA_FILE.jpg";
}
*/
else {
    // Jika kode tidak ditemukan
    $nama      = "Produk Tidak Ditemukan";
    $harga     = 0;
    $deskripsi = "-";
    $image     = "default.jpg";
}
// --- AKHIR AREA EDIT MANUAL ---
?>

<div class="container">
    <h2 style=" width: 100%; border-bottom: 4px solid #ffC0CB"><b>Detail produk</b></h2>

    <div class="row">
        <div class="col-md-4">
            <div class="thumbnail">
                <img src="image/produk/<?= $image; ?>" width="400">
            </div>
        </div>

        <div class="col-md-8">
            <form action="proses/add.php" method="GET">
                <input type="hidden" name="kd_cs" value="<?= $kode_cs; ?>">
                <input type="hidden" name="produk" value="<?= $kode;  ?>">
                <input type="hidden" name="hal"  value="2">
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td><b>Nama</b></td>
                            <td><?= $nama; ?></td>
                        </tr>
                        <tr>
                            <td><b>Harga</b></td>
                            <td>Rp.<?= number_format($harga); ?></td>
                        </tr>
                        <tr>
                            <td><b>Deskripsi</b></td>
                            <td><?= $deskripsi;  ?></td>
                        </tr>
                        <tr>
                            <td><b>Jumlah</b></td>
                            <td><input class="form-control" type="number" min="1" name="jml" value="1" style="width: 155px;"></td>
                        </tr>
                    </tbody>
                </table>
                
                <?php if(isset($_SESSION['user'])): ?>
                    <button type="submit" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart"></i> Tambahkan ke Keranjang</button>
                <?php else: ?>
                    <a href="keranjang.php" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart"></i> Tambahkan ke Keranjang</a>
                <?php endif; ?>
                
                <a href="index.php" class="btn btn-warning"> Kembali Belanja</a>
            </form>
        </div>
    </div>
</div>  
<br><br>

<?php 
include 'footer.php';
?>