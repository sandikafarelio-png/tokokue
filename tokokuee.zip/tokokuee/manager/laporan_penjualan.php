<?php 
include 'header.php';
// Gunakan format tahun 4 digit (Y) agar defaultnya 2025
$date = date('Y-m-d'); 

$date1 = $date;
$date2 = $date;

if(isset($_POST['submit'])){
    $date1 = $_POST['date1'];
    $date2 = $_POST['date2'];
}
?>
<style type="text/css">
    @media print{ .print{ display: none; } }
</style>
<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray; padding-bottom: 5px;"><b>Laporan Penjualan</b></h2>
    <div class="row print">
        <div class="col-md-9">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <table>
                    <tr>
                        <td><input type="date" name="date1" class="form-control" value="<?= $date1; ?>"></td>
                        <td>&nbsp; - &nbsp;</td>
                        <td><input type="date" name="date2" class="form-control" value="<?= $date2; ?>"></td>
                        <td> &nbsp;</td>
                        <td><input type="submit" name="submit" class="btn btn-primary" value="Tampilkan"></td>
                    </tr>
                </table>
            </form>
        </div>
        <div class="col-md-3 text-right">
            <form action="exp_penjualan.php" method="POST">
                <input type="hidden" name="date1" value="<?= $date1; ?>">
                <input type="hidden" name="date2" value="<?= $date2; ?>">
                <button type="submit" class="btn btn-success"><i class="glyphicon glyphicon-save-file"></i> Export to Excel</button>
                <a href="" onclick="window.print()" class="btn btn-default"><i class="glyphicon glyphicon-print"></i> Cetak</a>
            </form>
        </div>
    </div>
    <br><br>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Tanggal</th>
                <th>Total Penjualan (Rp)</th>
            </tr>
        </thead>
        <tbody>
        <?php 
        if(isset($_POST['submit'])){
            // Mengambil data dari tabel report _penjualan dengan backtick karena ada spasi
            $result = mysqli_query($conn, "SELECT * FROM `report _penjualan` WHERE tanggal BETWEEN '$date1' AND '$date2'");
            $no = 1;
            $total_pendapatan = 0;
            
            if(mysqli_num_rows($result) > 0){
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?= $no; ?></td>
                        <td><?= $row['nama_produk']; ?></td>
                        <td><?= $row['tanggal']; ?></td>
                        <td>Rp <?= number_format($row['jumlah_terjual']); ?></td>
                    </tr>
                    <?php 
                    $total_pendapatan += $row['jumlah_terjual'];
                    $no++;
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>Data tidak ditemukan untuk periode ini. Pastikan tahun filter adalah 2025.</td></tr>";
            }
            ?>
            <tr style="background-color: #eee;">
                <td colspan="3" class="text-right"><b>Total Pendapatan Terjual =</b></td>
                <td><b>Rp <?= number_format($total_pendapatan); ?></b></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<br><br><br><br><br>
<?php include 'footer.php'; ?>