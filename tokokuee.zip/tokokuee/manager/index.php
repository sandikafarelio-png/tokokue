<?php 
  session_start();
  // Jika session admin sudah ada, langsung lempar ke halaman_utama.php
  if(isset($_SESSION['admin'])){
    header('location:halaman_utama.php');
    exit; // Tambahkan exit agar kode di bawah tidak dijalankan
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Naturia Bakery - Login Manager</title>
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../css/style.css">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.css">
  <script src="../js/jquery.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</head>
<body>

  <script type="text/javascript">
    $( document ).ready(function() {
      // Trigger modal otomatis saat halaman dimuat
      $( "#target" ).click();
    });
  </script>

  <input type="hidden" id="target" data-toggle="modal" data-target="#exampleModal">

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="exampleModalLabel"><b>LOGIN MANAGER</b></h4>
        </div>
        <div class="modal-body">
          <form action="proses/login.php" method="POST">
            <div class="form-group">
              <label class="control-label">Username</label>
              <input type="text" class="form-control" placeholder="Username" name="user" autofocus required autocomplete="off">
            </div>
            <div class="form-group">
              <label class="control-label">Password</label>
              <input type="password" class="form-control" placeholder="Password" name="pass" required autocomplete="off">
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-warning" style="width: 100%;">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>