<?php 
session_start();
// 1. Pastikan file koneksi terpanggil (naik 2 folder)
include '../../koneksi/koneksi.php'; 

$username = mysqli_real_escape_string($conn, $_POST['user']);
$password = $_POST['pass'];

// 2. Ambil data admin berdasarkan username
$query = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username'");
$row = mysqli_fetch_assoc($query);

if($row){
    // 3. Verifikasi password hash dari database
    if(password_verify($password, $row['password'])){
        $_SESSION['admin'] = true;
        $_SESSION['user_admin'] = $row['username'];
        
        // 4. Redirect otomatis ke Dashboard
        header("location:../halaman_utama.php"); 
        exit; 
    } else {
        echo "<script>alert('Password Salah!'); window.location='../index.php';</script>";
    }
} else {
    echo "<script>alert('Username Tidak Ditemukan!'); window.location='../index.php';</script>";
}
?>