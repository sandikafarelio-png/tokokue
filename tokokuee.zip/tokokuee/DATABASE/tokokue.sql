-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2025 at 04:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokokue`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `role` enum('admin','manager') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626', 'admin'),
(2, 'manager', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626', 'manager');

-- --------------------------------------------------------

--
-- Table structure for table `bom_produk`
--

CREATE TABLE `bom_produk` (
  `kode_bom` varchar(100) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `kebutuhan` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bom_produk`
--

INSERT INTO `bom_produk` (`kode_bom`, `kode_bk`, `kode_produk`, `nama_produk`, `kebutuhan`) VALUES
('B0001', 'M0001', 'P0001', 'Bolu Pulut Hitam Keju', '2'),
('B0001', 'M0005', 'P0001', 'Bolu Pulut Hitam Keju', '6'),
('B0001', 'M0007', 'P0001', 'Bolu Pulut Hitam Keju', '2'),
('B0002', 'M0001', 'P0002', 'Bolu Jadul', '3'),
('B0002', 'M0003', 'P0002', 'Bolu Jadul', '2'),
('B0002', 'M0005', 'P0002', 'Bolu Jadul', '4'),
('B0003', 'M0001', 'P0003', 'Bolu Zebra', '2'),
('B0003', 'M0006', 'P0003', 'Bolu Zebra', '1'),
('B0003', 'M0005', 'P0003', 'Bolu Zebra', '4'),
('B0004', 'M0001', 'P0004', 'Bolu Keju', '2'),
('B0004', 'M0007', 'P0004', 'Bolu Keju', '3'),
('B0005', 'M0001', 'P0005', 'Bolu Pandan', '2'),
('B0005', 'M0009', 'P0005', 'Bolu Pandan', '1'),
('B0006', 'M0001', 'P0006', 'Bolu Caramel', '2'),
('B0006', 'M0002', 'P0006', 'Bolu Caramel', '4'),
('B0007', 'M0001', 'P0007', 'Bolu Komojo', '4'),
('B0007', 'M0008', 'P0007', 'Bolu Komojo', '2'),
('B0008', 'M0001', 'P0008', 'Cake Special', '4'),
('B0008', 'M0003', 'P0008', 'Cake Special', '3'),
('B0009', 'M0007', 'P0009', 'Cheese Cake', '5'),
('B0009', 'M0008', 'P0009', 'Cheese Cake', '2'),
('B0010', 'M0002', 'P0010', 'Bika Ambon', '3'),
('B0010', 'M0005', 'P0010', 'Bika Ambon', '8'),
('B0011', 'M0003', 'P0011', 'Lapis Legit', '6'),
('B0011', 'M0005', 'P0011', 'Lapis Legit', '15'),
('B0012', 'M0003', 'P0012', 'Kue Sus Spesial', '2'),
('B0012', 'M0008', 'P0012', 'Kue Sus Spesial', '2'),
('B0013', 'M0001', 'P0013', 'Croissant', '3'),
('B0013', 'M0003', 'P0013', 'Croissant', '4'),
('B0014', 'M0001', 'P0014', 'Pie Buah', '2'),
('B0014', 'M0002', 'P0014', 'Pie Buah', '1'),
('B0015', 'M0001', 'P0015', 'Bolen Pisang', '3'),
('B0015', 'M0003', 'P0015', 'Bolen Pisang', '2'),
('B0016', 'M0006', 'P0016', 'Brownies Cookies', '3'),
('B0016', 'M0002', 'P0016', 'Brownies Cookies', '2'),
('B0017', 'M0006', 'P0017', 'Chocolate Swiss Roll', '2'),
('B0017', 'M0005', 'P0017', 'Chocolate Swiss Roll', '5'),
('B0018', 'M0001', 'P0018', 'Donut Keju', '3'),
('B0018', 'M0004', 'P0018', 'Donut Keju', '1'),
('B0018', 'M0007', 'P0018', 'Donut Keju', '2');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `kode_customer` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`kode_customer`, `nama`, `email`, `username`, `password`, `telp`) VALUES
('C0001', 'Rafi Akbar', 'a.rafy@gmail.com', 'rafi', '$2y$10$/UjGYbisTPJhr8MgmT37qOXo1o/HJn3dhafPoSYbOlSN1E7olHIb.', '0856748564'),
('C0002', 'Nagita Silvana', 'bambang@gmail.com', 'Nagita', '$2a$12$bHl7aq/MLaKJpDw5fgjYUuGjo2fYFT5s/RB5tLj6XKRVDK09t/4ci', '087804616097'),
('C0003', 'Nadiya', 'nadiya@gmail.com', 'nadiya', '$2y$10$6wHH.7rF1q3JtzKgAhNFy.4URchgJC8R.POT1osTAWmasDXTTO7ZG', '0898765432'),
('C0004', 'Pitto', 'pitto@gmail.com', 'pitto', '$2y$10$uCWzkacIwm3rjTtfNEnrKOzXM0ACrW0Ij9oPYVuEQaoqbLPYWsek.', '0812345674');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `kode_bk` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `satuan` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`kode_bk`, `nama`, `qty`, `satuan`, `harga`, `tanggal`) VALUES
('M0001', 'Tepung Terigu', '1000', 'kg', 12000, '0000-00-00'),
('M0002', 'Gula Pasir', '500', 'kg', 15000, '0000-00-00'),
('M0003', 'Mentega', '300', 'kg', 25000, '0000-00-00'),
('M0004', 'Pengembang / Ragi', '100', 'kg', 45000, '0000-00-00'),
('M0005', 'Telur Ayam', '1000', 'butir', 2000, '0000-00-00'),
('M0006', 'Coklat Bubuk', '200', 'kg', 55000, '0000-00-00'),
('M0007', 'Keju Kraft', '150', 'kg', 60000, '0000-00-00'),
('M0008', 'Susu Cair', '200', 'liter', 18000, '0000-00-00'),
('M0009', 'Pandan Pasta', '50', 'botol', 10000, '0000-00-00'),
('M0010', 'Baking Powder', '80', 'kg', 35000, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `kode_customer` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `kode_produk` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`kode_produk`, `nama`, `image`, `deskripsi`, `harga`) VALUES
('P0001', 'Bolu Pulut Hitam Keju', 'bolupuluthitam.jpg', 'Bolu lembut dengan pulut hitam asli dan taburan keju melimpah.', 85000),
('P0002', 'Bolu Jadul', 'bolu.jpg', 'Cita rasa klasik bolu jadul yang tak terlupakan.', 70000),
('P0003', 'Bolu Zebra', 'boluzebra.jpg', 'Bolu dengan motif zebra coklat vanilla yang cantik dan lembut.', 70000),
('P0004', 'Bolu Keju', 'bolukeju.jpg', 'Bolu panggang dengan rasa keju yang gurih.', 70000),
('P0005', 'Bolu Pandan', 'bolupandan.jpg', 'Aroma pandan asli dengan tekstur yang sangat empuk.', 70000),
('P0006', 'Bolu Caramel', 'bolucaramel.jpg', 'Bolu sarang semut dengan rasa caramel yang legit.', 70000),
('P0007', 'Bolu Komojo', 'bolukomojo.jpg', 'Bolu komojo dengan motif cantik.', 65000),
('P0008', 'Cake Special', 'cake.jpg', 'Kue bolu lembut dengan lapisan krim istimewa.', 80000),
('P0009', 'Cheese Cake', 'cheesecake.jpg', 'Kue keju panggang yang lumer di mulut.', 65000),
('P0010', 'Bika Ambon', 'bikaambon.jpg', 'Kue tradisional bika ambon dengan tekstur berserat dan legit.', 65000),
('P0011', 'Lapis Legit', 'lapislegit.jpg', 'Kue lapis legit premium dengan aroma rempah yang harum.', 65000),
('P0012', 'Kue Sus Spesial', 'kuesus.jpg', 'Kue sus dengan isian vla vanilla yang melimpah.', 50000),
('P0013', 'Croissant', 'croisant.jpg', 'Roti prancis yang renyah di luar dan lembut di dalam.', 40000),
('P0014', 'Pie Buah', 'pie.jpg', 'Kulit pie renyah dengan topping buah-buahan segar.', 35000),
('P0015', 'Bolen Pisang', 'bolen.jpg', 'Pisang bolu lilit dengan coklat dan keju.', 30000),
('P0016', 'Brownies Cookies', 'BrowniesCokies.jpg', 'Perpaduan renyahnya cookies dan lembutnya brownies.', 35000),
('P0017', 'Chocolate Swiss Roll', 'ChocolateSwissRoll.jpg', 'Bolu gulung coklat dengan isian krim coklat pekat.', 60000),
('P0018', 'Donut Keju', 'donutkeju.jpg', 'Donat lembut dengan taburan keju melimpah.', 35000);

-- --------------------------------------------------------

--
-- Table structure for table `produksi`
--

CREATE TABLE `produksi` (
  `id_order` int(11) NOT NULL,
  `invoice` varchar(200) NOT NULL,
  `kode_customer` varchar(200) NOT NULL,
  `kode_produk` varchar(200) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  `provinsi` varchar(200) NOT NULL,
  `kota` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kode_pos` varchar(200) NOT NULL,
  `terima` varchar(200) NOT NULL,
  `tolak` varchar(200) NOT NULL,
  `cek` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produksi`
--

INSERT INTO `produksi` (`id_order`, `invoice`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`, `status`, `tanggal`, `provinsi`, `kota`, `alamat`, `kode_pos`, `terima`, `tolak`, `cek`) VALUES
(1, 'INV1110', 'C0001', 'P0001', 'Bolu Pulut Hitam Keju', 2, 85000, 'Pesanan Diterima', '2025-11-10', 'Riau', 'Pekanbaru', 'Jl. Sudirman', '28288', '1', '0', 0),
(2, 'INV1111', 'C0002', 'P0002', 'Bolu Jadul', 3, 70000, 'Pesanan Diterima', '2025-11-11', 'Riau', 'Pekanbaru', 'Jl. Arifin Ahmad', '28288', '1', '0', 0),
(3, 'INV1112', 'C0003', 'P0003', 'Bolu Zebra', 1, 70000, 'Pesanan Diterima', '2025-11-12', 'Riau', 'Pekanbaru', 'Jl. Paus', '28288', '1', '0', 0),
(4, 'INV1113', 'C0004', 'P0004', 'Bolu Keju', 4, 70000, 'Pesanan Diterima', '2025-11-13', 'Riau', 'Pekanbaru', 'Jl. Nangka', '28288', '1', '0', 0),
(5, 'INV1114', 'C0001', 'P0005', 'Bolu Pandan', 2, 70000, 'Pesanan Diterima', '2025-11-14', 'Riau', 'Pekanbaru', 'Jl. Durian', '28288', '1', '0', 0),
(6, 'INV1115', 'C0002', 'P0006', 'Bolu Caramel', 5, 70000, 'Pesanan Diterima', '2025-11-15', 'Riau', 'Pekanbaru', 'Jl. Harapan Raya', '28288', '1', '0', 0),
(7, 'INV1116', 'C0003', 'P0007', 'Kue Komojo', 3, 65000, 'Pesanan Diterima', '2025-11-16', 'Riau', 'Pekanbaru', 'Jl. Riau', '28288', '1', '0', 0),
(8, 'INV1117', 'C0004', 'P0008', 'Cake Special', 1, 80000, 'Pesanan Diterima', '2025-11-17', 'Riau', 'Pekanbaru', 'Jl. Gobah', '28288', '1', '0', 0),
(9, 'INV1118', 'C0001', 'P0009', 'Cheese Cake', 2, 65000, 'Pesanan Diterima', '2025-11-18', 'Riau', 'Pekanbaru', 'Jl. Thamrin', '28288', '1', '0', 0),
(10, 'INV1119', 'C0002', 'P0010', 'Bika Ambon', 4, 65000, 'Pesanan Diterima', '2025-11-19', 'Riau', 'Pekanbaru', 'Jl. Kartini', '28288', '1', '0', 0),
(11, 'INV1120', 'C0003', 'P0011', 'Lapis Legit', 1, 65000, 'Pesanan Diterima', '2025-11-20', 'Riau', 'Pekanbaru', 'Jl. Diponegoro', '28288', '1', '0', 0),
(12, 'INV1121', 'C0004', 'P0012', 'Kue Sus Spesial', 10, 50000, 'Pesanan Diterima', '2025-11-21', 'Riau', 'Pekanbaru', 'Jl. Hangtuah', '28288', '1', '0', 0),
(13, 'INV1122', 'C0001', 'P0013', 'Croissant', 6, 40000, 'Pesanan Diterima', '2025-11-22', 'Riau', 'Pekanbaru', 'Jl. Sisingamangaraja', '28288', '1', '0', 0),
(14, 'INV1123', 'C0002', 'P0014', 'Pie Buah', 8, 35000, 'Pesanan Diterima', '2025-11-23', 'Riau', 'Pekanbaru', 'Jl. Setia Budi', '28288', '1', '0', 0),
(15, 'INV1124', 'C0003', 'P0015', 'Bolen Pisang', 5, 30000, 'Pesanan Diterima', '2025-11-24', 'Riau', 'Pekanbaru', 'Jl. Sultan Syarif Kasim', '28288', '1', '0', 0),
(16, 'INV1125', 'C0004', 'P0016', 'Brownies Cookies', 2, 40000, 'Pesanan Diterima', '2025-11-25', 'Riau', 'Pekanbaru', 'Jl. Melati', '28288', '1', '0', 0),
(17, 'INV1126', 'C0001', 'P0017', 'Chocolate Swiss Roll', 3, 70000, 'Pesanan Diterima', '2025-11-26', 'Riau', 'Pekanbaru', 'Jl. Pepaya', '28288', '1', '0', 0),
(18, 'INV1127', 'C0002', 'P0001', 'Bolu Pulut Hitam Keju', 1, 85000, 'Pesanan Diterima', '2025-11-27', 'Riau', 'Pekanbaru', 'Jl. Mangga', '28288', '1', '0', 0),
(19, 'INV1128', 'C0003', 'P0002', 'Bolu Jadul', 4, 70000, 'Pesanan Diterima', '2025-11-28', 'Riau', 'Pekanbaru', 'Jl. Kopi', '28288', '1', '0', 0),
(20, 'INV1129', 'C0004', 'P0003', 'Bolu Zebra', 2, 70000, 'Pesanan Diterima', '2025-11-29', 'Riau', 'Pekanbaru', 'Jl. Ahmad Yani', '28288', '1', '0', 0),
(21, 'INV1130', 'C0001', 'P0004', 'Bolu Keju', 3, 70000, 'Pesanan Diterima', '2025-11-30', 'Riau', 'Pekanbaru', 'Jl. Tuanku Tambusai', '28288', '1', '0', 0),
(22, 'INV1201', 'C0002', 'P0010', 'Bika Ambon', 2, 65000, 'Pesanan Diterima', '2025-12-01', 'Riau', 'Pekanbaru', 'Jl. Durian', '28288', '1', '0', 0),
(23, 'INV1210', 'C0003', 'P0012', 'Kue Sus Spesial', 10, 50000, 'Pesanan Diterima', '2025-12-10', 'Riau', 'Pekanbaru', 'Jl. Sisingamangaraja', '28288', '1', '0', 0),
(24, 'INV1220', 'C0004', 'P0001', 'Bolu Pulut Hitam Keju', 1, 85000, 'Pesanan Baru', '2025-12-20', 'Riau', 'Pekanbaru', 'Jl. Melati', '28288', '2', '1', 0),
(25, 'INV1221', 'C0003', 'P0002', 'Bolu Jadul', 1, 70000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(26, 'INV1221', 'C0003', 'P0009', 'Cheese Cake', 1, 65000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(27, 'INV1221', 'C0003', 'P0008', 'Cake Special', 1, 80000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(28, 'INV1221', 'C0003', 'P0017', 'Chocolate Swiss Roll', 1, 60000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(29, 'INV1221', 'C0003', 'P0016', 'Brownies Cookies', 1, 35000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(30, 'INV1221', 'C0003', 'P0018', 'Donut Keju', 1, 35000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(31, 'INV1221', 'C0003', 'P0006', 'Bolu Caramel', 1, 70000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0),
(32, 'INV1222', 'C0004', 'P0003', 'Bolu Zebra', 1, 70000, 'Pesanan Baru', '2525-12-20', 'riau', 'pekanbaru', 'pandau', '28288', '0', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_cancel`
--

CREATE TABLE `report_cancel` (
  `id_report_cancel` int(11) NOT NULL,
  `id_order` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `jumlah` varchar(100) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_cancel`
--

INSERT INTO `report_cancel` (`id_report_cancel`, `id_order`, `kode_produk`, `jumlah`, `tanggal`) VALUES
(1, '24', 'P0001', '1', '2025-12-20');

-- --------------------------------------------------------

--
-- Table structure for table `report_inventory`
--

CREATE TABLE `report_inventory` (
  `id_report_inv` int(11) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `nama_bahanbaku` varchar(100) NOT NULL,
  `jml_stok_bk` int(11) NOT NULL,
  `tanggal` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_inventory`
--

INSERT INTO `report_inventory` (`id_report_inv`, `kode_bk`, `nama_bahanbaku`, `jml_stok_bk`, `tanggal`) VALUES
(1, 'M0001', 'Tepung Terigu', 950, '2025-11-10'),
(2, 'M0002', 'Gula Pasir', 480, '2025-11-12'),
(3, 'M0003', 'Mentega', 290, '2025-11-15'),
(4, 'M0005', 'Telur Ayam', 900, '2025-11-21'),
(5, 'M0007', 'Keju Kraft', 140, '2025-11-30'),
(6, 'M0001', 'Tepung Terigu', 800, '2025-12-05'),
(7, 'M0004', 'Pengembang / Ragi', 95, '2025-12-10'),
(8, 'M0006', 'Coklat Bubuk', 180, '2025-12-15'),
(9, 'M0008', 'Susu Cair', 190, '2025-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `report_omset`
--

CREATE TABLE `report_omset` (
  `id_report_omset` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_omset` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_omset`
--

INSERT INTO `report_omset` (`id_report_omset`, `invoice`, `jumlah`, `total_omset`, `tanggal`) VALUES
(1, 'INV1110', 2, 170000, '2025-11-10'),
(2, 'INV1111', 3, 210000, '2025-11-11'),
(3, 'INV1112', 1, 70000, '2025-11-12'),
(4, 'INV1113', 4, 280000, '2025-11-13'),
(5, 'INV1114', 2, 140000, '2025-11-14'),
(6, 'INV1115', 5, 350000, '2025-11-15'),
(7, 'INV1116', 3, 195000, '2025-11-16'),
(8, 'INV1117', 1, 80000, '2025-11-17'),
(9, 'INV1118', 2, 130000, '2025-11-18'),
(10, 'INV1119', 4, 260000, '2025-11-19'),
(11, 'INV1120', 1, 65000, '2025-11-20'),
(12, 'INV1121', 10, 500000, '2025-11-21'),
(13, 'INV1122', 6, 510000, '2025-11-22'),
(14, 'INV1123', 8, 280000, '2025-11-23'),
(15, 'INV1124', 5, 150000, '2025-11-24'),
(16, 'INV1125', 2, 80000, '2025-11-25'),
(17, 'INV1126', 3, 210000, '2025-11-26'),
(18, 'INV1127', 1, 85000, '2025-11-27'),
(19, 'INV1128', 4, 280000, '2025-11-28'),
(20, 'INV1129', 2, 140000, '2025-11-29'),
(21, 'INV1130', 3, 210000, '2025-11-30'),
(22, 'INV1201', 2, 130000, '2025-12-01'),
(23, 'INV1202', 1, 65000, '2025-12-02'),
(24, 'INV1203', 2, 100000, '2025-12-03'),
(25, 'INV1204', 1, 40000, '2025-12-04'),
(26, 'INV1205', 1, 35000, '2025-12-05'),
(27, 'INV1206', 1, 30000, '2025-12-06'),
(28, 'INV1207', 1, 40000, '2025-12-07'),
(29, 'INV1208', 1, 70000, '2025-12-08'),
(30, 'INV1209', 1, 70000, '2025-12-09'),
(31, 'INV1210', 10, 500000, '2025-12-10'),
(32, 'INV1211', 1, 85000, '2025-12-11'),
(33, 'INV1212', 1, 70000, '2025-12-12'),
(34, 'INV1213', 1, 70000, '2025-12-13'),
(35, 'INV1214', 1, 70000, '2025-12-14'),
(36, 'INV1215', 1, 70000, '2025-12-15'),
(37, 'INV1216', 1, 70000, '2025-12-16'),
(38, 'INV1217', 1, 65000, '2025-12-17'),
(39, 'INV1218', 1, 80000, '2025-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `report _penjualan`
--

CREATE TABLE `report _penjualan` (
  `id_report_sell` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_terjual` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report _penjualan`
--

INSERT INTO `report _penjualan` (`id_report_sell`, `invoice`, `kode_produk`, `nama_produk`, `jumlah_terjual`, `tanggal`) VALUES
(1, 'INV1110', 'P0001', 'Bolu Pulut Hitam Keju', 170000, '2025-11-10'),
(2, 'INV1111', 'P0002', 'Bolu Jadul', 210000, '2025-11-11'),
(3, 'INV1112', 'P0003', 'Bolu Zebra', 70000, '2025-11-12'),
(4, 'INV1113', 'P0004', 'Bolu Keju', 280000, '2025-11-13'),
(5, 'INV1114', 'P0005', 'Bolu Pandan', 140000, '2025-11-14'),
(6, 'INV1115', 'P0006', 'Bolu Caramel', 350000, '2025-11-15'),
(7, 'INV1116', 'P0007', 'Bolu Komojo', 195000, '2025-11-16'),
(8, 'INV1117', 'P0008', 'Cake Special', 80000, '2025-11-17'),
(9, 'INV1118', 'P0009', 'Cheese Cake', 130000, '2025-11-18'),
(10, 'INV1119', 'P0010', 'Bika Ambon', 260000, '2025-11-19'),
(11, 'INV1120', 'P0011', 'Lapis Legit', 65000, '2025-11-20'),
(12, 'INV1121', 'P0012', 'Kue Sus Spesial', 500000, '2025-11-21'),
(13, 'INV1122', 'P0001', 'Bolu Pulut Hitam Keju', 510000, '2025-11-22'),
(14, 'INV1123', 'P0014', 'Pie Buah', 280000, '2025-11-23'),
(15, 'INV1124', 'P0015', 'Bolen Pisang', 150000, '2025-11-24'),
(16, 'INV1125', 'P0016', 'Brownies Cookies', 80000, '2025-11-25'),
(17, 'INV1126', 'P0017', 'Chocolate Swiss Roll', 210000, '2025-11-26'),
(18, 'INV1127', 'P0001', 'Bolu Pulut Hitam Keju', 85000, '2025-11-27'),
(19, 'INV1128', 'P0002', 'Bolu Jadul', 280000, '2025-11-28'),
(20, 'INV1129', 'P0003', 'Bolu Zebra', 140000, '2025-11-29'),
(21, 'INV1130', 'P0004', 'Bolu Keju', 210000, '2025-11-30'),
(22, 'INV1201', 'P0010', 'Bika Ambon', 130000, '2025-12-01'),
(23, 'INV1202', 'P0011', 'Lapis Legit', 65000, '2025-12-02'),
(24, 'INV1203', 'P0012', 'Kue Sus Spesial', 100000, '2025-12-03'),
(25, 'INV1204', 'P0013', 'Croissant', 40000, '2025-12-04'),
(26, 'INV1205', 'P0014', 'Pie Buah', 35000, '2025-12-05'),
(27, 'INV1206', 'P0015', 'Bolen Pisang', 30000, '2025-12-06'),
(28, 'INV1207', 'P0016', 'Brownies Cookies', 40000, '2025-12-07'),
(29, 'INV1208', 'P0017', 'Chocolate Swiss Roll', 70000, '2025-12-08'),
(30, 'INV1209', 'P0018', 'Donut Keju', 70000, '2025-12-09'),
(31, 'INV1210', 'P0012', 'Kue Sus Spesial', 500000, '2025-12-10'),
(32, 'INV1211', 'P0001', 'Bolu Pulut Hitam Keju', 85000, '2025-12-11'),
(33, 'INV1212', 'P0002', 'Bolu Jadul', 70000, '2025-12-12'),
(34, 'INV1213', 'P0003', 'Bolu Zebra', 70000, '2025-12-13'),
(35, 'INV1214', 'P0004', 'Bolu Keju', 70000, '2025-12-14'),
(36, 'INV1215', 'P0005', 'Bolu Pandan', 70000, '2025-12-15'),
(37, 'INV1216', 'P0006', 'Bolu Caramel', 70000, '2025-12-16'),
(38, 'INV1217', 'P0007', 'Bolu Komojo', 65000, '2025-12-17'),
(39, 'INV1218', 'P0008', 'Cake Special', 80000, '2025-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `report_produksi`
--

CREATE TABLE `report_produksi` (
  `id_report_prd` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_produksi`
--

INSERT INTO `report_produksi` (`id_report_prd`, `invoice`, `kode_produk`, `nama_produk`, `qty`, `tanggal`) VALUES
(1, 'INV1110', 'P0001', 'Bolu Pulut Hitam Keju', 2, '2025-11-10'),
(2, 'INV1111', 'P0002', 'Bolu Jadul', 3, '2025-11-11'),
(3, 'INV1112', 'P0003', 'Bolu Zebra', 1, '2025-11-12'),
(4, 'INV1113', 'P0004', 'Bolu Keju', 4, '2025-11-13'),
(5, 'INV1114', 'P0005', 'Bolu Pandan', 2, '2025-11-14'),
(6, 'INV1115', 'P0006', 'Bolu Caramel', 5, '2025-11-15'),
(7, 'INV1116', 'P0007', 'Bolu Komojo', 3, '2025-11-16'),
(8, 'INV1117', 'P0008', 'Cake Special', 1, '2025-11-17'),
(9, 'INV1118', 'P0009', 'Cheese Cake', 2, '2025-11-18'),
(10, 'INV1119', 'P0010', 'Bika Ambon', 4, '2025-11-19'),
(11, 'INV1120', 'P0011', 'Lapis Legit', 1, '2025-11-20'),
(12, 'INV1121', 'P0012', 'Kue Sus Spesial', 10, '2025-11-21'),
(13, 'INV1122', 'P0001', 'Bolu Pulut Hitam Keju', 6, '2025-11-22'),
(14, 'INV1123', 'P0014', 'Pie Buah', 8, '2025-11-23'),
(15, 'INV1124', 'P0015', 'Bolen Pisang', 5, '2025-11-24'),
(16, 'INV1125', 'P0016', 'Brownies Cookies', 2, '2025-11-25'),
(17, 'INV1126', 'P0017', 'Chocolate Swiss Roll', 3, '2025-11-26'),
(18, 'INV1127', 'P0001', 'Bolu Pulut Hitam Keju', 1, '2025-11-27'),
(19, 'INV1128', 'P0002', 'Bolu Jadul', 4, '2025-11-28'),
(20, 'INV1129', 'P0003', 'Bolu Zebra', 2, '2025-11-29'),
(21, 'INV1130', 'P0004', 'Bolu Keju', 3, '2025-11-30'),
(22, 'INV1201', 'P0010', 'Bika Ambon', 2, '2025-12-01'),
(23, 'INV1202', 'P0011', 'Lapis Legit', 1, '2025-12-02'),
(24, 'INV1203', 'P0012', 'Kue Sus Spesial', 2, '2025-12-03'),
(25, 'INV1204', 'P0013', 'Croissant', 1, '2025-12-04'),
(26, 'INV1205', 'P0014', 'Pie Buah', 1, '2025-12-05'),
(27, 'INV1206', 'P0015', 'Bolen Pisang', 1, '2025-12-06'),
(28, 'INV1207', 'P0016', 'Brownies Cookies', 1, '2025-12-07'),
(29, 'INV1208', 'P0017', 'Chocolate Swiss Roll', 1, '2025-12-08'),
(30, 'INV1209', 'P0018', 'Donut Keju', 1, '2025-12-09'),
(31, 'INV1210', 'P0012', 'Kue Sus Spesial', 10, '2025-12-10'),
(32, 'INV1211', 'P0001', 'Bolu Pulut Hitam Keju', 1, '2025-12-11'),
(33, 'INV1212', 'P0002', 'Bolu Jadul', 1, '2025-12-12'),
(34, 'INV1213', 'P0003', 'Bolu Zebra', 1, '2025-12-13'),
(35, 'INV1214', 'P0004', 'Bolu Keju', 1, '2025-12-14'),
(36, 'INV1215', 'P0005', 'Bolu Pandan', 1, '2025-12-15'),
(37, 'INV1216', 'P0006', 'Bolu Caramel', 1, '2025-12-16'),
(38, 'INV1217', 'P0007', 'Bolu Komojo', 1, '2025-12-17'),
(39, 'INV1218', 'P0008', 'Cake Special', 1, '2025-12-18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`kode_bk`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indexes for table `produksi`
--
ALTER TABLE `produksi`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `report_cancel`
--
ALTER TABLE `report_cancel`
  ADD PRIMARY KEY (`id_report_cancel`);

--
-- Indexes for table `report_inventory`
--
ALTER TABLE `report_inventory`
  ADD PRIMARY KEY (`id_report_inv`);

--
-- Indexes for table `report_omset`
--
ALTER TABLE `report_omset`
  ADD PRIMARY KEY (`id_report_omset`);

--
-- Indexes for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  ADD PRIMARY KEY (`id_report_sell`);

--
-- Indexes for table `report_produksi`
--
ALTER TABLE `report_produksi`
  ADD PRIMARY KEY (`id_report_prd`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `produksi`
--
ALTER TABLE `produksi`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `report_cancel`
--
ALTER TABLE `report_cancel`
  MODIFY `id_report_cancel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `report_inventory`
--
ALTER TABLE `report_inventory`
  MODIFY `id_report_inv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `report_omset`
--
ALTER TABLE `report_omset`
  MODIFY `id_report_omset` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  MODIFY `id_report_sell` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `report_produksi`
--
ALTER TABLE `report_produksi`
  MODIFY `id_report_prd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
