<?php 
include 'header.php';
// Pastikan variabel $kode_cs sudah didefinisikan di header.php dari session customer
?>
<div class="container-fluid" style="margin: 0;padding: 0;">
    <div class="image" style="margin-top: -21px">
        <img src="image/home/Dashboard.jpg" style="width: 100%; height: 650px; object-fit: cover;">
    </div>
</div>
<br>
<br>

<div class="container">
    <h4 class="text-center" style="font-family: arial; padding-top: 10px; padding-bottom: 10px; font-style: italic; line-height: 29px; border-top: 2px solid #ffc0cb; border-bottom: 2px solid #ffc0cb;">
    Naturia Bakery adalah salah satu pelopor pertama dalam bisnis roti modern di Indonesia. Didirikan pada tahun 2025, saat ini dikelola di bawah PT. Kelompok 5. Produk kami sehat, bergizi, dan terjangkau oleh semua orang.
    </h4>

    <h2 style=" width: 100%; border-bottom: 4px solid #ffC0CB; margin-top: 80px;"><b>Produk Kami</b></h2>

    <div class="row">

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolupuluthitam.jpg" style="width: 100%; height: 250px; object-fit: cover;"> 
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Pulut Hitam Keju</h3> 
                    <h4 style="color: #e67e22;">Rp.85,000</h4> 
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0001" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0001&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolu.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu jadul</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0002" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0002&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/boluzebra.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Zebra</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0003" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0003&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<br><br><br><br>
<?php 
include 'footer.php';
?>