
	<footer style="border-top: 4px solid #ffC0CB;  ">
		<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4">
					<h3 style="color: #ffC0CB"><b>NATURIA BAKERY</b></h3>
					<p><i class="glyphicon glyphicon-earphone"></i> +62888282823</p>
					<p><i class="glyphicon glyphicon-envelope"></i> naturiabakery@gmail.com</p>
				</div>
				<div class="col-md-4">
					<h5><b>Menu</b></h5>
					<p><a href=""  style="color: #000">Produk</a></p>
					<p><a href=""  style="color: #000">Tentang kami</a></p>
					<p><a href=""  style="color: #000">Hubungi Kami</a></p>
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color: #ffC0CB; padding: 5px; color: #fff; text-align: center;">
			<span>Copyright&copy; KELOMPOK 5 </span>
		</div>
	</footer>

</body>
</html>