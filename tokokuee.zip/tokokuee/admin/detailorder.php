<?php 
include 'header.php';
$invoices = $_GET['inv'];
$d_order = mysqli_query($conn, "SELECT * FROM produksi WHERE invoice = '$invoices'");
$t_order = mysqli_fetch_assoc($d_order);

// Customer
$cs = mysqli_query($conn, "SELECT * FROM customer WHERE kode_customer = '".$t_order['kode_customer']."'");
$t_cs = mysqli_fetch_assoc($cs);

// FIX: Inisialisasi array kosong di awal agar tidak error NULL
$nama_material = array(); 
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray"><b>Detail Pesanan</b></h2>
    <br>
    <a href="produksi.php" class="btn btn-default"><i class="glyphicon glyphicon-arrow-left"></i> Kembali</a>
    
    <table class="table table-striped" style="margin-top: 20px;">
        <thead>
            <tr>
                <th>No</th>
                <th>Invoice</th>
                <th>Kode Customer</th>
                <th>Status</th>
                <th>Tanggal</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Query dengan ORDER BY agar berurutan dan terbaru di bawah
            $result = mysqli_query($conn, "SELECT DISTINCT invoice, kode_customer, status, kode_produk, qty, terima, tolak, cek, tanggal FROM produksi GROUP BY invoice ORDER BY tanggal ASC");
            $no = 1;
            while($row = mysqli_fetch_assoc($result)){
                $kodep = $row['kode_produk'];
                $inv = $row['invoice'];
                ?>
                <tr>
                    <td><?= $no; ?></td>
                    <td><?= $row['invoice']; ?></td>
                    <td><?= $row['kode_customer']; ?></td>
                    <td>
                        <?php if($row['terima'] == 1){ echo "<b style='color:green'>Diterima</b>"; }
                        else if($row['tolak'] == 1){ echo "<b style='color:red'>Ditolak</b>"; }
                        else { echo "<b style='color:orange'>".$row['status']."</b>"; } ?>
                    </td>
                    
                    <?php 
                    // Logika Cek Stok (BOM)
                    $t_bom = mysqli_query($conn, "SELECT * FROM bom_produk WHERE kode_produk = '$kodep'");
                    while($row1 = mysqli_fetch_assoc($t_bom)){
                        $kodebk = $row1['kode_bk'];
                        $res_inv = mysqli_query($conn, "SELECT * FROM inventory WHERE kode_bk = '$kodebk'");
                        $r_inv = mysqli_fetch_assoc($res_inv);

                        if(($r_inv['qty'] - ($row1['kebutuhan'] * $row['qty'])) < 0 && $row['tolak'] == 0 && $row['terima'] == 0){
                            mysqli_query($conn, "UPDATE produksi SET cek = '1' WHERE invoice = '$inv'");
                            $nama_material[] = $r_inv['nama']; // Mengisi array jika stok kurang
                        }
                    }
                    ?>
                    <td><?= $row['tanggal']; ?></td>
                    <td>
                        <a href="detailorder.php?inv=<?= $row['invoice']; ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-eye-open"></i> Detail</a>
                    </td>
                </tr>
            <?php $no++; } ?>
        </tbody>
    </table>

    <button type="hidden" data-toggle="modal" data-target="#myModal" id="btn" style="display:none;"></button>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">#<?= $t_order['invoice']; ?></h4>
                </div>
                <div class="modal-body">
                    <table class="table table-striped">
                        <tr><td>Customer</td><td><?= $t_order['kode_customer']; ?> - <?= $t_cs['nama']; ?></td></tr>
                        <tr><td>No Telp</td><td><?= $t_cs['telp']; ?></td></tr>
                        <tr><td>Alamat</td><td><?= $t_order['alamat'].", ".$t_order['kota']; ?></td></tr>
                    </table>
                    <hr>
                    <h4>List Order</h4>
                    <table class="table table-striped">
                        <tr><th>Produk</th><th>Harga</th><th>Qty</th><th>Subtotal</th></tr>
                        <?php 
                        $order_list = mysqli_query($conn, "SELECT * FROM produksi WHERE invoice = '$invoices'");
                        $grand = 0;
                        while ($list = mysqli_fetch_assoc($order_list)) {
                            $sub = $list['harga'] * $list['qty'];
                            $grand += $sub;
                        ?>
                        <tr>
                            <td><?= $list['nama_produk']; ?></td>
                            <td><?= number_format($list['harga']); ?></td>
                            <td><?= $list['qty']; ?></td>
                            <td><?= number_format($sub); ?></td>
                        </tr>
                        <?php } ?>
                        <tr><td colspan="4" class="text-right"><b>Total = Rp. <?= number_format($grand); ?></b></td></tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <a href="produksi.php" class="btn btn-default">Tutup</a>
                </div>
            </div>
        </div>
    </div>

    <?php if(count($nama_material) > 0){ ?>
    <div class="row" style="margin-top: 20px;">
        <div class="col-md-4 bg-danger" style="padding:15px; border-radius:5px;">
            <h4 style="color:white">Kekurangan Material</h4>
            <table class="table table-condensed" style="background:white">
                <?php 
                $unique_mat = array_values(array_unique($nama_material));
                foreach($unique_mat as $i => $mat){
                    echo "<tr><td>".($i+1)."</td><td>$mat</td></tr>";
                } ?>
            </table>
        </div>
    </div>
    <?php } ?>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#btn").click();
    });
</script>

<?php include 'footer.php'; ?>