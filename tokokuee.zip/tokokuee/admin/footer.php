<div class="copy" style="background-color: #ffC0CB; padding: 5px; color: #fff; text-align: center;">
			<span>Copyright&copy;  2024 NaturiaBakery </span>
</footer>
</body>
</html>

