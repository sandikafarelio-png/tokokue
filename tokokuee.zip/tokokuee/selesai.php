<?php 
    include 'header.php';
    // Ambil data terbaru dari database untuk ditampilkan sebagai ringkasan (opsional)
    // Pastikan variabel session sudah ada
    $kode_cs = $_SESSION['kd_cs'];
 ?>

<div class="container" style="padding-bottom: 300px;">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="alert alert-success text-center" style="margin-top: 30px; border-radius: 10px;">
                <h2 style="font-weight: bold;"><i class="glyphicon glyphicon-ok-sign"></i> Checkout Berhasil</h2>
            </div>
            
            <div class="panel panel-default" style="border: 1px solid #ffc0cb;">
                <div class="panel-body text-center">
                    <h4 style="font-weight: bold; line-height: 30px;">
                        Terimakasih Sudah Berbelanja di Naturia Bakery, <br>
                        Pesananmu sedang kami verifikasi. Silahkan tunggu barangmu tiba di rumah ya.. :)
                    </h4>
                    <hr style="border-top: 2px solid #ffc0cb;">
                    
                    <div style="background: #fdf2f4; padding: 20px; border-radius: 8px;">
                        <p style="font-size: 16px;">Status Pesanan Saat Ini:</p>
                        <h3 class="label label-warning" style="font-size: 20px; padding: 10px;">Pesanan Baru (Pending)</h3>
                        <br><br>
                        
                    </div>

                    <div style="margin-top: 30px;">
                        <a href="index.php" class="btn btn-default">Kembali ke Toko</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 <?php 
    include 'footer.php';
 ?>