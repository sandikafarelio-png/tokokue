<?php 
    include 'header.php';
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid #ffC0CB; margin-top: 20px; padding-bottom: 10px;"><b>Produk Kami</b></h2>

    <div class="row">
        
        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolupuluthitam.jpg" style="width: 100%; height: 250px; object-fit: cover;"> 
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Pulut Hitam Keju</h3> 
                    <h4 style="color: #e67e22;">Rp.85,000</h4> 
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0001" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0001&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolu.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu jadul</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0002" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0002&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/boluzebra.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Zebra</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0003" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0003&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolukeju.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Keju</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0004" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0004&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolupandan.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Pandan</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0005" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0005&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolucaramel.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Caramel</h3>
                    <h4 style="color: #e67e22;">Rp.70,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0006" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0006&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolukomojo.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolu Komojo</h3>
                    <h4 style="color: #e67e22;">Rp.65,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0007" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0007&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/cake.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Cake</h3>
                    <h4 style="color: #e67e22;">Rp.80,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0008" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0008&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/cheesecake.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">cheese Cake</h3>
                    <h4 style="color: #e67e22;">Rp.65,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0009" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0009&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bikaambon.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bika Ambon</h3>
                    <h4 style="color: #e67e22;">Rp.65,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0010" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0010&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/lapislegit.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Lapis Legit</h3>
                    <h4 style="color: #e67e22;">Rp.65,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0011" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0011&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/kuesus.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Kue Sus Spesial</h3>
                    <h4 style="color: #e67e22;">Rp.50,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0012" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0012&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/croisant.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Croissant</h3>
                    <h4 style="color: #e67e22;">Rp.40,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0013" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0013&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/pie.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Pie</h3>
                    <h4 style="color: #e67e22;">Rp.35,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0014" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0014&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/bolen.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Bolen</h3>
                    <h4 style="color: #e67e22;">Rp.30,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0015" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0015&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/BrowniesCokies.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Brownies Cookies</h3>
                    <h4 style="color: #e67e22;">Rp.40,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0016" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0016&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/ChocolateSwissRoll.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Chocolate Swiss Roll</h3>
                    <h4 style="color: #e67e22;">Rp.60,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0017" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0017&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-4">
            <div class="thumbnail" style="margin-bottom: 30px;">
                <img src="image/produk/donutkeju.jpg" style="width: 100%; height: 250px; object-fit: cover;">
                <div class="caption">
                    <h3 style="height: 50px; overflow: hidden; font-size: 18px;">Donut Keju</h3>
                    <h4 style="color: #e67e22;">Rp.35,000</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="detail_produk.php?produk=P0018" class="btn btn-warning btn-block">Detail</a> 
                        </div>
                        <div class="col-md-6">
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <a href="proses/add.php?produk=P0018&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block">Tambah</a>
                            <?php }else{ ?>
                                <a href="user_login.php" class="btn btn-success btn-block" onclick="return confirm('Silahkan Login Terlebih Dahulu Sebelum Berbelanja')">Tambah</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php 
    include 'footer.php';
?>