<?php 
include 'header.php';

// PROSES UPDATE JUMLAH (QTY)
if(isset($_POST['submit1'])){
    $id_keranjang = $_POST['id'];
    $qty = $_POST['qty'];

    $edit = mysqli_query($conn, "UPDATE keranjang SET qty = '$qty' WHERE id_keranjang = '$id_keranjang'");
    if($edit){
        echo "
        <script>
        alert('KERANJANG BERHASIL DIPERBARUI');
        window.location = 'keranjang.php';
        </script>
        ";
    }
}

// PROSES HAPUS PRODUK
else if(isset($_GET['del'])){
    $id_keranjang = $_GET['id'];
    $del = mysqli_query($conn, "DELETE FROM keranjang WHERE id_keranjang = '$id_keranjang'");
    if($del){
        echo "
        <script>
        alert('1 PRODUK DIHAPUS');
        window.location = 'keranjang.php';
        </script>
        ";
    }
}
?>

<div class="container" style="padding-bottom: 300px;">
    <h2 style="width: 100%; border-bottom: 4px solid #ffc0cb; margin-top: 20px; padding-bottom: 10px;"><b>Keranjang Belanja</b></h2>
    <table class="table table-striped table-hover">
        <?php 
        if(isset($_SESSION['kd_cs'])){
            $kode_cs = $_SESSION['kd_cs'];
            
            // CEK APAKAH ADA ITEM DI KERANJANG
            $cek = mysqli_query($conn, "SELECT * FROM keranjang WHERE kode_customer = '$kode_cs'");
            $jml = mysqli_num_rows($cek);

            if($jml > 0){
                ?>  
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Image</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Qty</th>
                        <th scope="col">SubTotal</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $result = mysqli_query($conn, "SELECT k.id_keranjang as keranjang, k.kode_produk as kd, k.nama_produk as nama_keranjang, k.qty as jml, p.nama as nama_p, p.image as gambar, p.harga as hrg 
                                             FROM keranjang k 
                                             LEFT JOIN produk p ON k.kode_produk = p.kode_produk 
                                             WHERE k.kode_customer = '$kode_cs'");
                $no = 1;
                $grand_total = 0;
                
                while($row = mysqli_fetch_assoc($result)){
                    $harga = ($row['hrg'] > 0) ? $row['hrg'] : 0;
                    $nama_tampil = (!empty($row['nama_p'])) ? $row['nama_p'] : $row['nama_keranjang'];
                    $subtotal = $harga * $row['jml'];
                ?>
                    <tr>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                            <input type="hidden" name="id" value="<?= $row['keranjang']; ?>">
                            <th scope="row"><?= $no; ?></th>
                            <td>
                                <?php if(!empty($row['gambar'])): ?>
                                    <img src="image/produk/<?= $row['gambar']; ?>" width="100" height="100" style="object-fit: cover; border-radius: 8px;">
                                <?php else: ?>
                                    <div style="width: 100px; height: 100px; background: #eee; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #999;">No Image</div>
                                <?php endif; ?>
                            </td>
                            <td><?= $nama_tampil; ?></td>
                            <td>Rp.<?= number_format($harga); ?></td>
                            <td>
                                <input type="number" name="qty" class="form-control" style="text-align: center; width: 80px;" value="<?= $row['jml']; ?>" min="1">
                            </td>
                            <td>Rp.<?= number_format($subtotal); ?></td>
                            <td>
                                <button type="submit" name="submit1" class="btn btn-warning btn-sm">Update</button>
                                <a href="keranjang.php?del=1&id=<?= $row['keranjang']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin dihapus?')">Delete</a>
                            </td>
                        </form>
                    </tr>
                <?php 
                    $grand_total += $subtotal;
                    $no++;
                }
                ?>
                    <tr>
                        <td colspan="5" style="text-align: right; font-weight: bold; font-size: 18px;">Grand Total =</td>
                        <td colspan="2" style="font-weight: bold; font-size: 18px; color: #d9534f;">Rp.<?= number_format($grand_total); ?></td>
                    </tr>
                    
                    <tr>
                        <td colspan="4"></td>
                        <td colspan="3" style="text-align: right;">
                            <div class="form-group" style="text-align: left; background: #fff5f7; padding: 15px; border-radius: 8px; border: 1px solid #ffc0cb; margin-bottom: 15px;">
                                <label style="color: #d9534f;"><i class="glyphicon glyphicon-credit-card"></i> <b>Pilih Metode Pembayaran:</b></label>
                                <select name="metode" class="form-control" style="border: 1px solid #ffc0cb;">
                                    <option value="BCA">Transfer Bank BCA - 1234567890 (a/n Naturia Bakery)</option>
                                    <option value="Mandiri">Transfer Bank Mandiri - 0987654321 (a/n Naturia Bakery)</option>
                                    <option value="Dana">E-Wallet DANA - 081268216601 (a/n Sandika)</option>
                                </select>
                                <p style="font-size: 11px; color: #999; margin-top: 5px;">*Metode ini akan digunakan untuk proses verifikasi di halaman checkout.</p>
                            </div>

                            <a href="produk.php" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart"></i> Lanjutkan Belanja</a>
                            
                            <a href="checkout.php?kode_cs=<?= $kode_cs; ?>" class="btn btn-primary">Lanjutkan Ke Checkout <i class="glyphicon glyphicon-chevron-right"></i></a>
                        </td>
                    </tr>
                </tbody>
                <?php 
            } else {
                // PERBAIKAN: Link Lihat Produk Kami juga ke produk.php
                 echo "<tbody><tr><td colspan='7' class='text-center bg-warning' style='padding: 50px;'><h5><b>KERANJANG BELANJA ANDA KOSONG</b></h5><br><a href='produk.php' class='btn btn-primary'>Lihat Produk Kami</a></td></tr></tbody>";
            }
        } else {
            echo "<tbody><tr><td colspan='7' class='text-center bg-danger' style='padding: 50px; color: white;'><h5><b>SILAHKAN LOGIN TERLEBIH DAHULU SEBELUM BERBELANJA</b></h5><br><a href='user_login.php' class='btn btn-default'>Login Sekarang</a></td></tr></tbody>";
        }
        ?>
    </table>
</div>

<?php include 'footer.php'; ?>